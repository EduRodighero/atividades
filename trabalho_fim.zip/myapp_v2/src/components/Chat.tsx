import {  Card, CardGroup, Image } from "react-bootstrap";
import { Comentario } from "./Comentario.types";

interface Props {
    comentarios: Comentario[]
}

export function Chat({comentarios}: Props) {
    const formatarNumero = (numero: number) => {
        const opcoes = { minimumIntegerDigits: 2 };
        return numero.toLocaleString('pt-BR', opcoes);
    }

    return(
        <>
            <Card>
                <Card.Header>
                Comentários {formatarNumero(comentarios.length)}
                </Card.Header>
                {
                    comentarios.map((comentario: Comentario, indice: number) => {
                        return (
                            <Card.Body key={indice} style={{backgroundColor: 'secondary'}}>
                                <CardGroup>
                                    <Image src="user_profile.png" rounded height={30} />
                                    <Card.Text>
                                        <b>{comentario.autor}</b> - {comentario.dataPublicacao}
                                    </Card.Text>
                                </CardGroup>
                                <Card.Text>
                                    <b>{comentario.comentario}</b>
                                </Card.Text>
                            </Card.Body>
                        );
                        })
                }
            </Card>
        </>
    )
}
  