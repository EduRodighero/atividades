export function Footer() {
  return(
    <footer>
      <h4>Todos os direitos reservados</h4>
    </footer>
  )
}
