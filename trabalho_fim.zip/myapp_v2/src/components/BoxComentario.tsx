import { useState } from "react";
import { Button, Row } from "react-bootstrap";

export function BoxComentario({onAdicionarComentario}) {
    const [autor, setAutor] = useState('');
    const [texto, setTexto] = useState('');

    const formatarNumero = (numero: number) => {
        const opcoes = { minimumIntegerDigits: 2 };
        return numero.toLocaleString('pt-BR', opcoes);
    }

    const adicionar = () => {
        const data = new Date()
        const dataFormatada = `${data.toLocaleDateString('pt-br')} ${data.getHours()}:${formatarNumero(data.getMinutes())}`
        const comentario = {
            autor: autor,
            comentario: texto,
            dataPublicacao: dataFormatada
        }

        if (autor !== '' && texto !== '') {
            onAdicionarComentario(comentario)

            setAutor('')
            setTexto('')
        }
    }

    return(
      <>
        <div style={{width: '100%'}}>
            <Row>
                <label htmlFor="autor">Nome usuário: </label>
                <input value={autor} name="autor" id="autor" onChange={(event) => setAutor(event.target.value)}/>
            </Row>
            <Row>
                <label htmlFor="comentario">Comentário: </label>
                <textarea value={texto} name="comentario" id="comentario" onChange={(event) => setTexto(event.target.value)}/>
            </Row>
            <Row>
                <Button disabled={autor === '' || texto === ''} style={{marginTop: '20px'}} variant="success" onClick={adicionar}>Enviar</Button>
            </Row>
        </div>
      </>
    )
  }
  