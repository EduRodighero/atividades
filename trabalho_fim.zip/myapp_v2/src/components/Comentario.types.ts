export interface Comentario {
    autor: string;
    comentario: string;
    dataPublicacao: string;
}