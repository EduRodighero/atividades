import "bootstrap/dist/css/bootstrap.min.css";
import { Chat } from "./components/Chat";
import { Comentario } from "./components/Comentario.types";
import { BoxComentario } from "./components/BoxComentario";
import { Header } from "./components/header";
import { Col, Row } from "react-bootstrap";
import { useEffect, useState } from "react";

export default function App() {
  const [comentarios, setComentarios] = useState([] as Comentario[])

  useEffect(() => {
    const comentariosPagina = localStorage.getItem('comentarios')
    if (comentariosPagina) {
      const comments = JSON.parse(comentariosPagina);
      if (comments) {
        setComentarios(comments);
      }
    }
  }, [])

  const obterComentarios = () => {
    return comentarios
  };

  const adicionarComentario = (comentario: Comentario) => {
    const comentariosNovos = [comentario, ...comentarios] as Comentario[]
    setComentarios(comentariosNovos);

    localStorage.setItem('comentarios', JSON.stringify(comentariosNovos));
  }

  return (
    <div>
      <Header/>

      <Row>
        <Col xs={12} lg={4} md={4} sm={12} style={{padding: '30px'}}>
          <BoxComentario onAdicionarComentario={adicionarComentario} />
        </Col>

        <Col xs={12} lg={7} md={12} sm={12} style={{padding: '30px'}}>
          <Chat comentarios={obterComentarios()} />
        </Col>
      </Row>
    </div>
  );
}
