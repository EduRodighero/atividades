import { useCallback, useRef, useState } from 'react';
import { Button, Container, Nav, Navbar, Table } from 'react-bootstrap';
import './App.css';
import FilmeItem from './FilmeItem';
import ModalCadastro from './modal/ModalCadastro';
import Filme from './types/Filme.type';

function App() {
  const [filmes, setFilmes] = useState([] as Filme[])
  const scrollRef = useRef<any>(null);

  const [id, setId] = useState(1);

  const deletarFilme = useCallback((filmeExcluir: Filme) => {
    const novosFilmes = filmes.filter(filme => filme.id !== filmeExcluir.id)
    setFilmes(novosFilmes)
  }, [filmes])

  const editarFilme = useCallback((filmeEdicao: Filme) => {
    const filmesAlterado = filmes.map(filme => {
      if (filme.id === filmeEdicao.id) {
        return {
          id: filmeEdicao.id,
          imagem: filmeEdicao.imagem,
          titulo: filmeEdicao.titulo,
          sinopse: filmeEdicao.sinopse,
          elenco: filmeEdicao.elenco,
          classificacao: filmeEdicao.classificacao
        } as Filme
      }
      return filme
    })
    setFilmes([...filmesAlterado])
  }, [filmes]);

  const listaFilmes = filmes.map(filme => 
    <FilmeItem editarFilme={editarFilme} deletarFilme={deletarFilme} filme={filme}/>
  )

  const salvarFilme = (filme: Filme) => {
    filme.id = id
    setId(id+1)
    setFilmes([...filmes, filme])
  }

  const voltarAoTopo = () => {
    window.scrollTo({ top: scrollRef.current.offsetTop, left: 0, behavior: 'smooth' });
  }

  return (
    <div className="App">
      <Navbar ref={scrollRef} expand="lg" className="bg-body-tertiary">
          <Container>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
              <Nav className="me-auto">
                <Nav.Link href="#home">EduardoFlix</Nav.Link>
                <Nav.Link href="#link">
                  <ModalCadastro salvarFilme={salvarFilme}/>
                </Nav.Link>
              </Nav>
            </Navbar.Collapse>
          </Container>
        </Navbar>
      <header className="App-header">
        <Table variant="dark">
          <thead>
            <tr>
              <th>Id</th>
              <th>Imagem</th>
              <th>Título</th>
              <th>Editar</th>
              <th>Ver</th>
              <th>Remover</th>
            </tr>
          </thead>
          <tbody>
            {listaFilmes}
          </tbody>
        </Table>
        <Button
          onClick={voltarAoTopo}
          title="Learn More"
          color="#841584">
            Voltar ao topo
        </Button>
      </header>
    </div>
  );
}

export default App;
