import { useCallback, useState } from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Modal from 'react-bootstrap/Modal';
import Filme from '../types/Filme.type';
import { FaPencilAlt } from 'react-icons/fa';

interface Props {
    filme: Filme,
    editarFilme: (filme: Filme) => void;
}

function ModalEdicao(props: Props) {
  const [show, setShow] = useState(false);
  const [titulo, setTitulo] = useState(props.filme.titulo);
  const [imagem, setImagem] = useState(props.filme.imagem);
  const [sinopse, setSinopse] = useState(props.filme.sinopse);
  const [elenco, setElenco] = useState(props.filme.elenco);
  const [classificacao, setClassificacao] = useState(props.filme.classificacao);

  const handleClose = useCallback(() => setShow(false), []);
  const handleShow = useCallback(() => setShow(true), []);

  const handleSave = () => {
    const filme = {
        id: props.filme.id,
        imagem,
        titulo,
        sinopse,
        elenco,
        classificacao
    } as Filme

    props.editarFilme(filme)
    handleClose();
  }

  const alterarImagem = (event: React.ChangeEvent<HTMLInputElement>) => {
    setImagem(event.target.value)
  }

  const alterarTitulo = (event: React.ChangeEvent<HTMLInputElement>) => {
    setTitulo(event.target.value)
  }

  const alterarSinopse = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSinopse(event.target.value)
  }

  const alterarElenco = (event: React.ChangeEvent<HTMLInputElement>) => {
    setElenco(event.target.value)
  }

  const alterarClassificacao = (event: React.ChangeEvent<HTMLInputElement>) => {
    setClassificacao(event.target.value)
  }

  return (
    <>
      <FaPencilAlt onClick={handleShow}/>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Editar filme</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Link Imagem</Form.Label>
              <Form.Control
                onChange={alterarImagem}
                value={imagem}
                placeholder="https://google.com/images/image.png"
                autoFocus
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Titulo</Form.Label>
              <Form.Control
                onChange={alterarTitulo}
                value={titulo}
                placeholder="Titanic"
                autoFocus
              />
            </Form.Group>
            <Form.Group
              className="mb-3"
              controlId="exampleForm.ControlTextarea1"
            >
              <Form.Label>Sinopse</Form.Label>
              <Form.Control 
                onChange={alterarSinopse} 
                as="textarea" 
                rows={3}
                value={sinopse} />
            </Form.Group>
            <Form.Group
              className="mb-3"
              controlId="exampleForm.ControlTextarea1"
            >
              <Form.Label>Elenco</Form.Label>
              <Form.Control 
                value={elenco}
                onChange={alterarElenco} 
                as="textarea" 
                rows={2} />
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Classificação</Form.Label>
              <Form.Control
                placeholder="Livre, 14, 16"
                autoFocus
                onChange={alterarClassificacao}
                value={classificacao}
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Fechar
          </Button>
          <Button variant="primary" onClick={handleSave}>
            Editar
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default ModalEdicao;