import { useCallback, useState } from 'react';
import { Col, Row } from 'react-bootstrap';
import Modal from 'react-bootstrap/Modal';
import { FaEye } from 'react-icons/fa';
import Filme from '../types/Filme.type';

interface Props {
    filme: Filme
}

function ModalDetalhes(props: Props) {
  const [show, setShow] = useState(false);

  const handleClose = useCallback(() => setShow(false), [show]);
  const handleShow = useCallback(() => setShow(true), [show]);

  return (
    <>
      <FaEye onClick={handleShow}/>

      <Modal show={show} onHide={handleClose} animation={false}>
        <Modal.Header closeButton>
          <Modal.Title>Detalhes</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <Row>
            <Col md={3}>
                <label>Id:</label>
            </Col>
            <Col>
                <span id="passwordHelpBlock">
                    {props.filme.id}
                </span>
            </Col>
        </Row>
        <Row>
            <Col md={3}>
                <label>Imagem:</label>
            </Col>
            <Col>
                <img 
                    style={{width: '80%', height: '150px'}}
                    alt="imagem"
                    src={props.filme.imagem} />
            </Col>
        </Row>
        <Row>
            <Col md={3}>
                <label>Título:</label>
            </Col>
            <Col>
                <span id="passwordHelpBlock">
                    {props.filme.titulo}
                </span>
            </Col>
        </Row>
        <Row>
            <Col md={3}>
                <label>Sinopse:</label>
            </Col>
            <Col>
                <span id="passwordHelpBlock">
                    {props.filme.sinopse}
                </span>
            </Col>
        </Row>
        <Row>
            <Col md={3}>
                <label>Elenco:</label>
            </Col>
            <Col>
                <span id="passwordHelpBlock">
                    {props.filme.elenco}
                </span>
            </Col>
        </Row>
        <Row>
            <Col md={3}>
                <label>Classificação:</label>
            </Col>
            <Col>
                <span id="passwordHelpBlock">
                    {props.filme.classificacao}
                </span>
            </Col>
        </Row>
        </Modal.Body>
      </Modal>
    </>
  );
}

export default ModalDetalhes;