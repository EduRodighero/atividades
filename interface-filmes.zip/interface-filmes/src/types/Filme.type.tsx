export default interface Filme {
    id: number,
    titulo: string,
    imagem: string,
    sinopse: string,
    elenco: string,
    classificacao: string
    visivel: boolean
}
