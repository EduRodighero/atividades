import { FaRegTrashAlt } from "react-icons/fa";
import './App.css';
import ModalDetalhes from './modal/ModalDetalhes';
import ModalEdicao from "./modal/ModalEdicao";
import Filme from './types/Filme.type';

interface Props {
    filme: Filme,
    deletarFilme: (filme: Filme) => void,
    editarFilme: (filme: Filme) => void
}

function FilmeItem(props: Props) {

  return (
    <tr>
      <td>
        {props.filme.id}
      </td>
      <td>
        <img 
          style={{width: '40%', height: '50px'}}
          alt="imagem"
          src={props.filme.imagem} />
      </td>
      <td>
        {props.filme.titulo}
      </td>
      <td>
        <ModalEdicao filme={props.filme} editarFilme={(filme) => props.editarFilme(filme)}/>
      </td>
      <td>
        <ModalDetalhes filme={props.filme} />
      </td>
      <td>
        <FaRegTrashAlt onClick={() => props.deletarFilme(props.filme)}/>
      </td>
    </tr>
  );
}

export default FilmeItem;
